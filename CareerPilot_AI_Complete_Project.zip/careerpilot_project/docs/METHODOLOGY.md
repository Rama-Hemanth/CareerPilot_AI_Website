# Recommendation Methodology and Skill-Gap Algorithm

## Nature of the method
This prototype implements a **rule-based / content-based heuristic**, not a trained machine learning or deep learning system. It is appropriate as an explainable baseline in a data science capstone. Production claims of personalization or predictive accuracy require real data and proper evaluation.

## Feature representation
For each job, define its required-skill set `S_j`, required experience in years `e_j`, location `l_j`, and mode `m_j`. User profile provides `S_u`, experience `e_u`, and preferred location `l_u`.

## Scoring components

**Skill overlap:**

`K_j = |S_u ∩ S_j| / |S_j|`

**Experience compatibility:**

`E_j = 1` if `e_u >= e_j`, otherwise `max(0, 1 - 0.35(e_j - e_u))`.

**Location affinity:**

`L_j = 1` if `l_u = Any`, `l_u = l_j`, or the role is Remote; otherwise `0.25`.

**Final score:**

`score_j = round(100 × (0.75 K_j + 0.15 E_j + 0.10 L_j))`.

The score prioritizes skill fit, followed by experience and location. It is **not a probability** of selection, not an unbiased fairness measure, and not calibrated to hiring outcomes. Match scores may favor jobs with shorter skill lists; there is no weighting of mandatory vs optional skills.

## Worked example
Suppose a job requires eight skills, and the user knows five. The job requires 2 years of experience, while the user has 1; the preferred city differs and the role is Hybrid.

- `K = 5/8 = 0.625`
- `E = 1 - 0.35(2-1) = 0.65`
- `L = 0.25`
- Score `= round(100(0.75×0.625 + 0.15×0.65 + 0.10×0.25)) = round(59.125) = 59%`

## Role-level gap
For target role `r`, with canonical skill requirements `S_r`:

- **Known skills** `= S_r ∩ S_u`
- **Missing skills** `= S_r − S_u`
- **Coverage** `= 100 |S_r ∩ S_u| / |S_r|` (rounded)

The app displays required skills and known/missing indicators. Missing skills are currently listed in the defined role-template order, not computed by a validated market-demand importance model.

## Roadmap generation
1. Compute the missing skill list for the target role.
2. Split it into up to three sequential groups using `ceil(n_missing / 3)`.
3. Associate groups with Weeks 1–3, 4–7 and 8–12.
4. Add a portfolio task in the last phase.
5. Store task-completion toggles under a role-specific key in `localStorage`.
6. Map known skills to curated learning-resource URLs; otherwise offer a web search link.

Durations and learning priority are illustrative, not personalized forecasts.

## Resume-text recognition
The textbox uses case-insensitive word-boundary-like regex matching against the skill catalog. For each found catalog entry, it adds the corresponding skill. This approach is deterministic and lightweight but does not handle nuanced synonyms, negation, competency level, CV context, or semantic reasoning. For example, the phrase “no Python experience” still matches Python.

## Future evaluation plan
- Label relevant jobs for multiple synthetic or consenting real profiles; compute `Precision@K`, `Recall@K`, `NDCG@K`, and `MRR`.
- Evaluate skill extraction with human-labeled CV spans using precision, recall, and F1.
- Compare against simple TF-IDF, BM25, sentence embeddings, and hybrid recommenders.
- Use train/validation/test splits when learning model parameters and prevent duplicate posting leakage.
- Conduct task-based usability studies and measure roadmap usefulness and comprehension.
- Audit fairness, location, experience, salary confounding, and model explanations.

No actual accuracy or performance metrics have been collected by this prototype; do not fabricate them in reports.
