# Viva / Demo Presentation Guide

## 10-slide suggested outline
1. **Title and team:** CareerPilot AI — Job Recommendation & Skill Gap Analyzer.
2. **Motivation:** Job seekers need transparent matching and an actionable learning path.
3. **Problem statement:** Rank jobs from profile attributes; identify missing role skills.
4. **Objectives / modules:** Recommendations, gap analysis, roadmap, search, saved jobs.
5. **System architecture:** Browser UI → synthetic data + state → scoring engine → screens / exports.
6. **Dataset design:** 32 fictional postings, 8 career tracks, skills taxonomy, limitations.
7. **Algorithm:** 75% skill overlap, 15% experience, 10% location; example score.
8. **Product demo:** Dashboard, profile, filtered job list, detail modal.
9. **Results / testing:** Show UI behavior, sample computed scores and manual acceptance checks; do not invent model metrics.
10. **Limitations / future scope:** Real datasets, robust resume parsing, learned ranking, evaluation, privacy.

## Suggested live script
- Open `index.html` without starting a server.
- Show 4 summary statistics and top recommendations.
- Select a few new skills in Profile and save; show that results update.
- Open a job and explain its match percentage and missing skill tags.
- Run skill-gap analysis for an AI Engineer, generate a learning plan, check a task.
- Reload to show saved state, then export CSV or Markdown.

## Questions to prepare for
**Why call it AI?** The project explores AI-oriented job matching, but the current working baseline is an interpretable weighted rule rather than a trained AI model.

**Why synthetic data?** It makes the working demo reproducible and avoids unreliable real-time APIs and privacy issues. It cannot demonstrate labor-market validity.

**What is the novelty?** A cohesive explainable matching-to-learning workflow. Novel algorithmic contributions would require further experiments and comparisons.

**How will you evaluate?** Annotate query/profile-job relevance, assess ranking against baselines, evaluate extraction F1, and run usability studies.

**What data is stored?** Only local profile, bookmarks, theme and roadmap checkboxes in browser `localStorage`.
