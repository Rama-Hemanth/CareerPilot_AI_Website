# Test Plan and Acceptance Checklist

## Test environment
Test `index.html` directly in a recent Chrome/Edge/Firefox browser, with JavaScript enabled. Repeat basic checks in a narrow mobile viewport.

| ID | Scenario | Procedure | Expected result |
|---|---|---|---|
| T01 | Startup | Open HTML | Dashboard renders, no server requested |
| T02 | Nav | Open all sidebar sections | Each section appears correctly |
| T03 | Profile change | Add PyTorch and save | Skill counts and affected scores update |
| T04 | Text search | Search `SQL` | Only postings with matching text remain |
| T05 | Role filter | Choose Data Engineer | Exactly 4 postings in dataset before other filters |
| T06 | Mode filter | Choose Remote | Only remote postings visible |
| T07 | Sorting | Choose Highest salary | Results descend by `salaryMax` |
| T08 | Job details | Click View details | Modal displays details, matched/missing skills |
| T09 | Bookmark | Save a posting | It appears in Saved Jobs |
| T10 | Bookmark persistence | Reload page | Saved job remains |
| T11 | Skill gap | Choose AI Engineer | Coverage and missing skills shown |
| T12 | Learning tasks | Check a task, refresh | Checkbox remains checked |
| T13 | Resume helper | Load sample text, detect | Catalog skills are added |
| T14 | CSV export | Click Export matches CSV | CSV file downloads; quoted values properly escaped |
| T15 | JSON export | Export profile | JSON file downloads and parses |
| T16 | Markdown export | Export learning plan | `.md` file downloads |
| T17 | Dataset export | Download dataset | Valid JSON with `synthetic: true` and 32 jobs |
| T18 | Theme | Toggle theme twice | Color scheme switches and returns |
| T19 | Reset | Reset and confirm | Demo reverts to original profile/bookmarks/tasks |
| T20 | Empty search | Search improbable string | Friendly empty-state display |

## Unit-test ideas (future)
- Validate `match(job)` values are within [0, 100].
- With all required skills known, skill overlap equals 1.
- A job with zero missing skills reports an empty missing list.
- Role-level coverage is 100 when all canonical skills are selected.
- Equal job inputs always produce equal scores.
- Nonmatching text search produces no false matches.

## Caveats
This document lists manual acceptance procedures rather than claiming that every cross-browser test has been performed. For production, automate with Playwright/Cypress, add accessibility checks, test persistence fallback, and inspect for data leakage or invalid inputs.
