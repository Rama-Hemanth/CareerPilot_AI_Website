# Synthetic Dataset and Data Dictionary

## Provenance
The demo dataset is **generated locally from hardcoded templates**. The 32 postings are fictional and should never be represented as scraped, verified, live, or employer-provided information.

## Dataset size
- 32 synthetic job postings.
- 8 role families, 4 postings per family.
- 12 fictional company labels reused across postings.
- 6 locations: Bengaluru, Hyderabad, Pune, Chennai, Mumbai, Delhi NCR.
- 3 work modes: Remote, Hybrid, On-site.
- 41 unique recognized skill names in the global catalog.
- Jobs receive synthetic salary ranges (₹ LPA), seniority, and posted-day counters.

## Job fields
| Field | Type | Meaning |
|---|---|---|
| `id` | integer | Demo identifier (101–132) |
| `title` | string | Display job title |
| `role` | string | Canonical role family |
| `company` | string | Fictional company name |
| `companyBg` / `companyColor` | string | Decorative hex color |
| `location` | string | Indian city |
| `mode` | string | Remote, Hybrid, On-site |
| `experience` | integer | Required years, demo rule |
| `skills` | string array | Job-specific skill requirements |
| `salaryMin` / `salaryMax` | integer | Synthetic ₹ lakhs per annum |
| `postedDays` | integer | Demo recency label, not current metadata |
| `description` | string | Fictional posting description |
| `responsibilities` | string array | Illustrative duties |

## Profile fields
| Field | Type | Meaning |
|---|---|---|
| `name` | string | Display name |
| `experience` | number | Years of experience |
| `role` | string | Preferred career family |
| `location` | string | Preferred city or Any |
| `skills` | string array | Selected skills |

## Data generation
Job `i` chooses role `i % 8`, a company, city and mode based on fixed indexing rules, and a requirements subset drawn from the role taxonomy plus one supplemental skill. This makes the dataset deterministic and reproducible when loading the same HTML version.

## Data export
In **About Project**, click **Download bundled dataset JSON** to obtain the actual generated 32 posting objects. This data export is ideal for a JSON inspection or further Python analysis, but the website does not need it to run.

## Potential improvements
Use an appropriately licensed public dataset with documented sourcing, remove duplicates, normalize skill synonyms, add provenance timestamps, and clearly separate scraped hiring demand from applicant-created profiles.
