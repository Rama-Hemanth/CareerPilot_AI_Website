# Problem Statement and Research Context

## Motivation
Entry-level candidates often search broadly for opportunities without a transparent understanding of whether their current skills align with job requirements. A resume may also contain transferable skills that are not obviously reflected in keyword-only job search. A useful decision-support tool should explain why a role is relevant and highlight concrete skills a candidate can learn next.

## Problem formulation
Given user profile `U = (S_u, e_u, l_u)` with skills, years of experience and preferred location, and a collection of jobs `J = {j_1,...,j_n}` each with skill set `S_j`, minimum experience `e_j`, and location `l_j`, construct a ranking of jobs that:
- rewards covered required skills,
- accounts for basic experience compatibility,
- considers geographic/work-mode preferences,
- makes unmatched requirements visible.

For target career role `r` with canonical requirement set `S_r`, return `G_r = S_r \ S_u` and a role coverage value. Use `G_r` to create a progressive learning plan.

## Stakeholders
- Students and recent graduates
- Career switchers and job seekers
- Campus placement cells and advisors
- Researchers studying explainable recommendation and workforce skills

## Research questions for a future empirical study
RQ1: Does an explainable weighted skill-overlap baseline improve perceived transparency compared with keyword search alone?
RQ2: How do rankings change when candidate preferences and experience are considered?
RQ3: Can validated skill extraction from resume text improve recommendation relevance?
RQ4: Do skill-gap roadmaps improve perceived confidence or task completion?

## Hypotheses (not tested in this demo)
H1: Candidate-centered matching outperforms generic role keyword search on relevance judgments.
H2: Providing a skill breakdown increases user trust and understanding.
H3: Skill-gap-oriented learning plans increase the clarity of the user's next steps.

These hypotheses require real participants, an appropriate research protocol, and evaluation data. The current demonstration does not provide evidence for them.
