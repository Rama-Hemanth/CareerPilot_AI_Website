# Project Overview

## Project title
CareerPilot AI: Explainable Job Recommendation and Skill Gap Analysis System

## Abstract
This project presents an interactive, browser-only prototype that helps job seekers discover relevant opportunities and identify competencies needed for their target career roles. The system maintains an editable candidate profile, compares it against role-specific skills in a synthetic job dataset, ranks postings using weighted similarity, exposes missing skills, and generates a staged learning roadmap. The implementation uses a single standalone HTML file containing CSS, JavaScript, and deterministic job data. It provides local persistence, search/filter tools, bookmark management, and downloadable outputs. The prototype demonstrates an end-to-end decision-support workflow without relying on an external API or trained predictive model. Experimental extensions are proposed for future validation with real-world data.

## Objectives
1. Represent candidate skills, experience, and preferred location.
2. Recommend job postings by explainable similarity rather than opaque rankings.
3. Quantify skills acquired and missing for a chosen role.
4. Translate skill gaps into an actionable, task-based learning plan.
5. Support browsing, bookmarking, searching, and data exports in one offline app.
6. Provide an extensible foundation for future machine learning and NLP research.

## Scope
- Frontend functionality only, with realistic synthetic data.
- Eight role families, thirty-two postings, 41 catalog skills.
- Explainable scoring, rule-based skill identification, learning phases.
- Responsive desktop/mobile UI, dark mode, local persistence.

## Out of scope
- Real-time job feed, verified salaries, company identity, authentication, recruiter workflows, actual job applications, PDF/DOCX parsing, production security, online ML inference.

## Expected learning outcomes
Data cleaning and taxonomy design, feature representation, weighted similarity, top-k ranking, coverage-based gap analysis, interactive visualization, JS data manipulation, technical documentation, limitations and evaluation planning.

## Deliverable
A single `index.html` application plus reproducible documentation and optional in-app exports.
