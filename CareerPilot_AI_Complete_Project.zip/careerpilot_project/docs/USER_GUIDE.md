# User Manual

## Getting started
Open `index.html` in a browser. The left navigation links switch between all seven screens. The hamburger button reveals navigation on phones. Press **☾ Theme** to toggle dark mode.

## Personalizing your profile
1. Click **My Profile**.
2. Enter your display name and experience level.
3. Select preferred role and preferred city (or Any).
4. Click skills to add/remove them; selected skills have a purple appearance and checkmark.
5. Click **Save profile & refresh matches**. All job scores are recalculated.

**Resume helper:** Paste a few lines of resume text into the textbox, or click **Use sample resume**. Click **Detect skills & add to profile**. Catalog matches are added locally. They are not verified competencies. Save the main profile if you modify other fields.

## Finding and comparing jobs
1. Open **Explore Jobs**.
2. Type a term such as `PyTorch`, `Data Analyst`, or a company label.
3. Optionally filter role, city, and work mode.
4. Sort by best match, highest synthetic salary, fewest missing skills, or job title.
5. Click **View details** for the skills, duties, score explanation and missing skill list.
6. Click ♡ to save; click again to remove.

## Interpreting the match
A score of 80% means the weighted heuristic equals 80/100 with the selected preferences; it **does not** mean an 80% chance of an offer. Skill tags in green are already selected. Orange tags are unmatched skills.

## Learning what you lack
1. Open **Skill Gap Analysis**.
2. Choose a target role from the dropdown.
3. Check the coverage bar and list of missing competencies.
4. Click **Build learning roadmap** to generate three phases.
5. Tick the tasks as you complete them. The browser remembers progress between reloads.
6. Open suggested documentation/course links if you have internet access.

## Downloading results
- **Explore Jobs → Export matches CSV:** filtered and sorted posting details and current match score.
- **My Profile → Export profile JSON:** current in-memory profile.
- **Learning Roadmap → Download learning plan:** Markdown checklist.
- **About Project → Download bundled dataset JSON:** all synthetic postings.

## Resetting
Use **Reset demo data** in the sidebar and confirm. This clears the site's demo profile, bookmarks, tasks and theme, returning to defaults.

## FAQ
**Is there a real job API?** No. All job data is generated inside the HTML file.

**Why did a match score change?** Skills, experience, and location are inputs to the recommendation algorithm.

**Can I apply to jobs from the demo?** No; these are fabricated opportunities created for a class project.

**Is my pasted resume uploaded to any website?** No. This demo checks it in the local browser, and does not save the resume text itself.

**Why did it not recognize a skill?** The parser only recognizes catalog names, not every synonym or abbreviation.
