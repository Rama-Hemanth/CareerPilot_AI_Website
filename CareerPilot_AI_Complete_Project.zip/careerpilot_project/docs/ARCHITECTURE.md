# System Architecture and Data Flow

## High-level architecture

```mermaid
flowchart TD
  A[User interactions] --> B[Single-file HTML UI]
  B --> C[Profile and skill editor]
  B --> D[Job search and filter]
  B --> E[Gap and roadmap views]
  C --> F[Client-side recommendation engine]
  G[Bundled synthetic jobs] --> F
  G --> D
  F --> D
  F --> E
  E --> H[Learning resource catalog]
  C <--> I[Browser localStorage]
  D <--> I
  E <--> I
  D --> J[CSV export]
  C --> K[JSON export]
  E --> L[Markdown export]
```

## Data flow
1. App initializes with the bundled job-role taxonomy and synthetic listings.
2. Saved profile/bookmark/task state is read from `localStorage`, or default values are used.
3. Recommendation engine calculates an independent score for each posting.
4. Search/filter/sort operations operate on the job array and calculated scores.
5. Skill-gap analysis compares current skills to a canonical career-role requirement list.
6. Roadmap groups unmet skills into three progression phases, with optional external links.
7. Button actions write updated preferences or completed tasks to `localStorage`.

## Modules inside `index.html`
| Logical module | Key functions or constants |
|---|---|
| Data layer | `CATALOG`, `ROLES`, `JOBS`, `RESOURCES` |
| State | `profile`, `saved`, `tasks`, `safeLoad`, `saveState` |
| Ranking | `match`, `sortedJobs` |
| Skill intelligence | `roleAnalysis`, `gapRender` |
| Learning plan | `renderRoadmap` |
| UI | `homeRender`, `jobRender`, `savedRender`, `modalJob`, `go` |
| Export | `download` and related button callbacks |
| Events | Delegated document click handlers and input/change listeners |

## Security/privacy caveats
No API keys or remote data calls exist. Profile details in `localStorage` are not encrypted and should not be treated as safe storage for confidential personal data. Production design should add authentication, server-side validation, consent, retention controls, rate limiting, content security policy, and secure backend storage. Pasted resumes should not include sensitive personal details in demos.

## Database / API extension
See `API_AND_EXTENSIONS.md` for suggested normalized schema, endpoints, model pipeline, and deployment options.
