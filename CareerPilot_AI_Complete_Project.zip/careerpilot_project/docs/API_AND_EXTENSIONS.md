# API Integration and Future Research Extensions

## Current design
There is **no fake network request** and no live API in this version. Predefined data is bundled directly within `index.html` so the website still works completely offline and as a `file://` URL. The in-app JSON export demonstrates the future API's possible response structure.

## Illustrative production API contract (NOT implemented)

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/v1/jobs?role=&location=&mode=` | Retrieve job postings |
| GET | `/api/v1/jobs/{id}` | Retrieve one posting |
| PUT | `/api/v1/profile` | Save authenticated user's profile |
| POST | `/api/v1/recommendations` | Score and rank postings |
| POST | `/api/v1/skills/extract` | Extract and normalize skills from resume text |
| POST | `/api/v1/gaps` | Compute missing skills for selected target role |
| POST | `/api/v1/roadmaps` | Generate or save learning plan |

## Example hypothetical response

```json
{
  "profile_id": "demo-001",
  "model_version": "weighted-baseline-v1",
  "results": [
    {"job_id": 101, "match_score": 76, "missing_skills": ["Statistics", "A/B Testing"]}
  ]
}
```

## Proposed database design
`users(user_id, name, experience_years, preferred_role, preferred_city)`
`skills(skill_id, canonical_name, category)`
`user_skills(user_id, skill_id, proficiency, evidence)`
`jobs(job_id, company_id, title, role, location, mode, min_experience, posted_at, source_url)`
`job_skills(job_id, skill_id, importance, is_mandatory)`
`saved_jobs(user_id, job_id, saved_at)`
`learning_tasks(user_id, role, skill_id, state, updated_at)`

## AI/ML improvement roadmap
1. Ingest licensed job data through a reliable API; preserve source and timestamp.
2. Normalize title/skill variants with a controlled taxonomy (e.g., Python vs Python 3).
3. Train/evaluate multilabel skill extraction with annotated resumes and job descriptions.
4. Build TF-IDF/BM25 and sentence-embedding content retrieval baselines.
5. Consider hybrid ranking across overlap, contextual semantics, proficiency, preferences and explicit user feedback.
6. Learn ranker weights on labeled relevance data instead of guessing them.
7. Analyze calibration, user satisfaction, geographic fairness, career-stage effects, and exposure diversity.
8. Provide explanations grounded in actual input features; add human oversight and clear uncertainty labels.

## Suggested tech stack for a full project
- Frontend: React, Next.js or maintain current HTML.
- Backend: FastAPI / Flask.
- Database: PostgreSQL.
- Search: PostgreSQL full-text, OpenSearch, or FAISS for embeddings.
- Modeling: scikit-learn baselines, sentence-transformers, transformer NER.
- Evaluation: precision@K, nDCG@K, MRR, skill-extraction F1, controlled user studies.
- Deployment: containerization with Docker, CI tests, monitoring, and privacy controls.

## Academic honesty note
Do **not** describe the current heuristic as an experimentally validated ML model. It is a demonstrator and credible baseline for a later evidence-backed data science project.
