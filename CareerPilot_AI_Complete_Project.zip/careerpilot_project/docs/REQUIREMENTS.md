# Software Requirements Specification (Condensed)

## Functional requirements
| ID | Requirement | Implementation |
|---|---|---|
| FR-01 | Load default candidate profile | Prefilled sample profile |
| FR-02 | Edit name, skills, experience, target role, location | Profile screen |
| FR-03 | Rank jobs by explicit match score | Score function; dashboard/job list |
| FR-04 | Search role, company or skills | Live text search |
| FR-05 | Filter by role, location and work mode | Job listing selectors |
| FR-06 | Sort by score, salary, gaps or name | Job listing sort |
| FR-07 | Inspect full job requirements and gaps | Job detail modal |
| FR-08 | Bookmark and unbookmark roles | Saved Jobs screen |
| FR-09 | Analyze gap vs a target role | Skill Gap Analysis screen |
| FR-10 | Generate learning tasks and links | Learning Roadmap screen |
| FR-11 | Mark learning tasks complete | Persistent checkboxes |
| FR-12 | Detect catalog skills from pasted text | Browser-local resume-text detector |
| FR-13 | Save profile and preferences | `localStorage` |
| FR-14 | Export CSV, JSON, Markdown | Browser-generated downloads |
| FR-15 | Reset demo data | Reset control |
| FR-16 | Switch color theme | Theme control |

## Nonfunctional requirements
- **Portability:** Runs as a file in a modern browser.
- **Availability:** No external service dependency for core interactions.
- **Usability:** Responsive navigation, descriptive labels, feedback toasts.
- **Transparency:** A score formula and missing-skill explanations are available.
- **Privacy:** Profile and pasted text remain in the browser in this demo.
- **Reproducibility:** Same input and bundled dataset yield same rankings.
- **Performance:** Dataset is intentionally small enough for immediate client-side scoring.

## Hardware/software
- OS: Windows, macOS, Linux, Android, or iOS with modern web browser.
- Browser: Chrome, Edge, Firefox or Safari.
- Dependencies: None.
- Backend/API: None.
- Internet access: Only when following optional learning-resource links.

## Assumptions
Experience is measured in whole years, skill matching relies on canonical names, and salary ranges are synthetic amounts in INR lakh per annum (LPA).
